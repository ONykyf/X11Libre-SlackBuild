void
__noop_to_appease_ar__(void);

void
__noop_to_appease_ar__(void)
{
    return;
}
