#ifdef HAVE_XORG_CONFIG_H
#include <xorg-config.h>
#endif

#include "xf86_os_support.h"

void
xf86OSRingBell(int loudness, int pitch, int duration)
{
}
