/*
 * Copyright © 2019 Intel Corporation
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the next
 * paragraph) shall be included in all copies or substantial portions of the
 * Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 */

#ifndef __IGT_DEVICE_SCAN_H__
#define __IGT_DEVICE_SCAN_H__

#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <limits.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <unistd.h>

enum igt_devices_print_type {
	IGT_PRINT_SIMPLE = 0,
	IGT_PRINT_DETAIL,
	IGT_PRINT_USER, /* End user friendly. */
};

enum igt_devices_print_option {
	IGT_PRINT_DRM = 0,
	IGT_PRINT_SYSFS,
	IGT_PRINT_PCI,
};

struct igt_devices_print_format {
	enum igt_devices_print_type   type;
	enum igt_devices_print_option option;
	bool numeric;
	bool codename;
};

#define INTEGRATED_I915_GPU_PCI_ID "0000:00:02.0"
#define PCI_SLOT_NAME_SIZE 12
struct igt_device_card {
	char subsystem[NAME_MAX];
	char card[NAME_MAX];
	char render[NAME_MAX];
	char driver[NAME_MAX];
	char pci_slot_name[PCI_SLOT_NAME_SIZE+1];
	uint16_t pci_vendor, pci_device;
};

void igt_devices_scan(void);
void igt_devices_scan_all_attrs(void);

void igt_devices_print(const struct igt_devices_print_format *fmt);
void igt_devices_print_vendors(void);
void igt_device_print_filter_types(void);

void igt_devices_free(void);

/*
 * Handle device filter collection array.
 * IGT can store/retrieve filters passed by user using '--device' args.
 */

int igt_device_filter_count(void);
int igt_device_filter_add(const char *filter);
void igt_device_filter_free_all(void);
const char *igt_device_filter_get(int num);

int igt_device_filter_pci(void);

/* Use filter to match the device and fill card structure */
bool igt_device_card_match(const char *filter, struct igt_device_card *card);
bool igt_device_card_match_pci(const char *filter,
	struct igt_device_card *card);
int igt_device_card_match_all(const char *filter, struct igt_device_card **card);
bool igt_device_find_first_i915_discrete_card(struct igt_device_card *card);
bool igt_device_find_integrated_card(struct igt_device_card *card);
bool igt_device_find_first_xe_discrete_card(struct igt_device_card *card);
bool igt_device_find_xe_integrated_card(struct igt_device_card *card);
bool igt_device_find_card_by_sysname(const char *sysname,
				     struct igt_device_card *card);
char *igt_device_get_pretty_name(struct igt_device_card *card, bool numeric);
int igt_open_card(struct igt_device_card *card);
int igt_open_render(struct igt_device_card *card);

/* Add or use filters to match multiGPU devices */
int igt_device_prepare_filtered_view(const char *vendor);

#endif /* __IGT_DEVICE_SCAN_H__ */
