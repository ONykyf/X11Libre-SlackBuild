/*
 * Copyright © 2008 Intel Corporation
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the next
 * paragraph) shall be included in all copies or substantial portions of the
 * Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * Authors:
 *    Eric Anholt <eric@anholt.net>
 *
 */

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <err.h>
#include <assert.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include "i915_drm.h"

#include "drmtest.h"
#include "intel_chipset.h"
#include "igt_core.h"
#include "ioctl_wrappers.h"
#include "xe/xe_query.h"

/**
 * SECTION:intel_chipset
 * @short_description: Feature macros and chipset helpers
 * @title: Chipset
 * @include: igt.h
 *
 * This library mostly provides feature macros which use raw pci device ids. It
 * also provides a few more helper functions to handle pci devices, chipset
 * detection and related issues.
 */

/**
 * intel_pch:
 *
 * Global variable to keep track of the pch type. Can either be set manually or
 * detected at runtime with intel_check_pch().
 */
enum pch_type intel_pch;

/**
 * intel_pci_device_by_class:
 *
 * Looks up the main graphics pci device using libpciaccess.
 *
 * Returns:
 * The pci_device, exits the program on any failures.
 */
static struct pci_device *intel_pci_device_by_class(unsigned int class)
{
	struct pci_device *pci_dev;
	int error;

	error = igt_pci_system_init();
	igt_fail_on_f(error != 0,
		      "Couldn't initialize PCI system\n");

	/* Grab the Intel device. Try the canonical slot first, then
	 * walk the entire PCI bus for a matching device. */
	pci_dev = pci_device_find_by_slot(0, 0, 2, 0);
	if (pci_dev == NULL || pci_dev->vendor_id != 0x8086) {
		struct pci_device_iterator *iter;
		struct pci_id_match match;

		match.vendor_id = 0x8086; /* Intel */
		match.device_id = PCI_MATCH_ANY;
		match.subvendor_id = PCI_MATCH_ANY;
		match.subdevice_id = PCI_MATCH_ANY;

		match.device_class = class << 16;
		match.device_class_mask = 0xff << 16;

		match.match_data = 0;

		iter = pci_id_match_iterator_create(&match);
		pci_dev = pci_device_next(iter);
		pci_iterator_destroy(iter);
	}
	if (!pci_dev)
		return NULL;

	error = pci_device_probe(pci_dev);
	igt_fail_on_f(error != 0, "Couldn't probe the PCI device, class %#x\n", class);

	if (pci_dev->vendor_id != 0x8086)
		errx(1, "PCI device class %#x is non-intel", class);

	return pci_dev;
}

/**
 * intel_get_pci_device_display:
 *
 * Looks up display class pci device using libpciaccess
 *
 * Returns: The pci_device, exits the program on any failures
 */
struct pci_device *intel_get_pci_device_display(void)
{
	/* PCI display class (0x3) device */
	struct pci_device *pci_dev = intel_pci_device_by_class(0x3);

	igt_require_f(pci_dev, "Couldn't find Intel graphics device\n");

	return pci_dev;
}

/**
 * intel_get_pci_device:
 *
 * Looks up display and accelerator class pci devices using libpciaccess
 *
 * Returns: The pci_device, exits the program on any failures
 */
struct pci_device *intel_get_pci_device(void)
{
	/* PCI display class (0x3) device */
	struct pci_device *pci_dev = intel_pci_device_by_class(0x3);

	/* PCI accelerator class (0x12) device */
	if (!pci_dev)
		pci_dev = intel_pci_device_by_class(0x12);

	igt_require_f(pci_dev, "Couldn't find Intel graphics or accelerator device\n");

	return pci_dev;
}

static uint32_t __i915_get_drm_devid(int fd)
{
	struct drm_i915_getparam gp;
	int devid = 0;

	memset(&gp, 0, sizeof(gp));
	gp.param = I915_PARAM_CHIPSET_ID;
	gp.value = &devid;
	ioctl(fd, DRM_IOCTL_I915_GETPARAM, &gp, sizeof(gp));

	return devid;
}

/**
 * intel_get_drm_devid:
 * @fd: open i915/xe drm file descriptor
 *
 * Queries the kernel for the pci device id corresponding to the drm file
 * descriptor.
 *
 * Returns:
 * The devid, exits the program on any failures.
 */
uint32_t
intel_get_drm_devid(int fd)
{
	const char *override;

	igt_assert(is_intel_device(fd));

	override = getenv("INTEL_DEVID_OVERRIDE");
	if (override)
		return strtol(override, NULL, 0);

	if (is_i915_device(fd))
		return __i915_get_drm_devid(fd);
	else
		return xe_dev_id(fd);
}

/**
 * intel_check_pch:
 *
 * Detects the PCH chipset type of the running systems and fills in the results
 * into the global #intel_pch variable.
 */
void
intel_check_pch(void)
{
	struct pci_device *pch_dev;

	pch_dev = pci_device_find_by_slot(0, 0, 31, 0);
	if (pch_dev == NULL)
		return;

	if (pch_dev->vendor_id != 0x8086)
		return;

	switch (pch_dev->device_id & 0xff00) {
	case 0x3b00:
		intel_pch = PCH_IBX;
		break;
	case 0x1c00:
	case 0x1e00:
		intel_pch = PCH_CPT;
		break;
	case 0x8c00:
	case 0x9c00:
		intel_pch = PCH_LPT;
		break;
	default:
		intel_pch = PCH_NONE;
		return;
	}
}
