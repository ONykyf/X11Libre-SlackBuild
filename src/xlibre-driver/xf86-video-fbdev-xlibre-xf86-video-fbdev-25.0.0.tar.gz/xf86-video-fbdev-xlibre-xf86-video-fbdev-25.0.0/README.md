xf86-video-fbdev - video driver for framebuffer device
------------------------------------------------------

The primary development code repository can be found at:

  https://github.com/X11Libre/xf86-video-fbdev

Please submit bug reports and requests to merge patches there.
