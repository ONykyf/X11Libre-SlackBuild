xf86-input-elographics - Elographics input driver for the XLibre X server
-------------------------------------------------------------------------

The primary development code repository can be found at:

  https://github.com/X11Libre/xf86-input-elographics

Please submit bug reports and requests to merge patches there.
