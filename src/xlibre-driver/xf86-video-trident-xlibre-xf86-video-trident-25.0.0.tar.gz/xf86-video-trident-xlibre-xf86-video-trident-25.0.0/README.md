xf86-video-trident - Trident video driver for the XLIbre X server
-----------------------------------------------------------------

The primary development code repository can be found at:

  https://github.com/X11Libre/xf86-video-trident

Please submit bug reports and requests to merge patches there.
