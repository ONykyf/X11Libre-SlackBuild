xf86-video-savage - S3 Savage video driver for the XLibre X server
------------------------------------------------------------------

The primary development code repository can be found at:

  https://github.com/X11Libre/xf86-video-savage

Please submit bug reports and requests to merge patches there.
