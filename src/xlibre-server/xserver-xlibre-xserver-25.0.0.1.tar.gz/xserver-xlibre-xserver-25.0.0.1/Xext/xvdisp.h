extern void XineramifyXv(void);
extern int xvUseXinerama;
